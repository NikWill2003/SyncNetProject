#!/usr/bin/env python3
"""Peak VRAM of one forward+backward for the tuned baselines at several micro-batch sizes,
on synthetic data (no dataset needed), so a card can be chosen before renting:
    python scripts/vram_check.py                       # relnet (8x8) and conv, batches 256..2048
    python scripts/vram_check.py --bs 512,1024 --models relnet
Add the split size to the per-run total in gpu_cached mode: SQOOP train is ~13.3 GB on the card.
"""
from __future__ import annotations
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import torch
from hydra import compose, initialize_config_dir
from src.core.registry import build_loss_fn, build_model, register_configs

CELLS = {
    'relnet': ['task=sqoop', 'experiment=sqoop/baselines/thesis/relnet', 'model.pair_spatial=8'],
    'conv': ['task=sqoop', 'experiment=sqoop/baselines/thesis/conv'],
    'syncnet': ['task=sqoop', 'experiment=sqoop/sync/hybrids/identity_partition_cnnenc', 'model.readout_prior=false'],
}


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('--models', default='relnet,conv'); ap.add_argument('--bs', default='256,512,1024,2048'); ap.add_argument('--compile', action='store_true')
    args = ap.parse_args(); register_configs()
    assert torch.cuda.is_available(), 'needs a GPU'
    total = torch.cuda.get_device_properties(0).total_memory / 2**30
    print(f'{torch.cuda.get_device_name(0)} ({total:.0f} GB); bf16 autocast, one forward+backward+AdamW step, synthetic 64x64 batches')
    for name in args.models.split(','):
        with initialize_config_dir(config_dir=os.path.abspath('conf'), version_base='1.3'):
            cfg = compose(config_name='config', overrides=CELLS[name])
        loss_fn = build_loss_fn(cfg)
        for bs in (int(b) for b in args.bs.split(',')):
            torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()
            try:
                model = build_model(cfg).cuda()
                if args.compile: model = torch.compile(model)
                opt = torch.optim.AdamW(model.parameters(), lr=3e-4, fused=True)
                batch = {'images': torch.rand(bs, 3, 64, 64, device='cuda'), 'questions': torch.randint(0, 36, (bs, 3), device='cuda'), 'answers': torch.randint(0, 2, (bs,), device='cuda')}
                for _ in range(2):
                    with torch.autocast('cuda', dtype=torch.bfloat16):
                        loss, _ = loss_fn(model(batch), batch)
                    loss.backward(); opt.step(); opt.zero_grad(set_to_none=True)
                torch.cuda.synchronize()
                peak = torch.cuda.max_memory_allocated() / 2**30
                print(f'   {name:8s} bs {bs:5d}   peak {peak:6.2f} GB   (+13.3 GB split if gpu_cached -> {peak + 13.3:5.1f} GB per run)')
            except torch.cuda.OutOfMemoryError:
                print(f'   {name:8s} bs {bs:5d}   OOM on this card')
            finally:
                for k in ('model', 'opt', 'batch', 'loss'): locals().pop(k, None)
                torch.cuda.empty_cache()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
