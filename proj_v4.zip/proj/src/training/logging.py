from typing import Any, Literal, Optional
from dataclasses import dataclass
from pathlib import Path
import math
from collections import defaultdict

import wandb
from hydra.core.hydra_config import HydraConfig
from hydra.types import RunMode


# -- run identity ------------------------------------------------------------

def get_wandb_init(cfg, out_dir: str) -> dict[str, Any]:
    """Build the wandb init kwargs (name, group, tags, notes, ...) from the
    hydra runtime state. Explicit cfg.wandb values always win over the
    derived ones.

    Naming:
        single run   {model}::{date}::{time}
        multirun     {model}::multirun::{sweep_stamp}::{job_num}

    Grouping (multirun only): sweep stamp + the job's CLI overrides minus
    train.seed, so jobs differing only in seed share a group and collate
    (mean/std bands) in the wandb UI; any other difference splits them.

    Tags appended to cfg.wandb.tags: sweep:{stamp} (multirun), model:{choice},
    dataset:{name}, exp:{choice} (when an experiment was selected).
    """
    hc = HydraConfig.get()

    # what was selected for each defaults group; experiment is None when
    # not chosen (it is `optional` in config.yaml)
    choices = hc.runtime.choices
    model_choice = choices.get('model') or cfg.model.name
    exp_choice = choices.get('experiment')

    run_dir = Path(out_dir)
    overrides = list(hc.overrides.task)   # per-job overrides, seed substituted

    if hc.mode == RunMode.MULTIRUN:
        # outputs/<dataset>/multirun/<stamp>/<job_num>
        stamp, job_num = run_dir.parent.name, run_dir.name
        name = f'{model_choice}::multirun::{stamp}::{job_num}'

        non_seed = [o for o in overrides if not o.startswith('train.seed=')]
        group = f'{stamp}|{",".join(sorted(non_seed))}'

        auto_tags = [f'sweep:{stamp}']
    else:
        # outputs/<dataset>/<date>/<time>
        date, time = run_dir.parent.name, run_dir.name
        name = f'{model_choice}::{date}::{time}'
        group = None
        auto_tags = []

    auto_tags += [f'model:{model_choice}', f'dataset:{cfg.dataset.name}']
    if exp_choice:
        auto_tags.append(f'exp:{exp_choice}')

    return {
        'entity': cfg.wandb.entity,
        'name': cfg.wandb.run_name or name,
        'group': cfg.wandb.group or group,
        'tags': list(cfg.wandb.tags) + auto_tags,
        'notes': ' '.join(overrides),   # the exact command behind this run
        'job_type': 'train',
        'dir': out_dir,
    }


# -- metric sectioning -------------------------------------------------------
#
# Metrics stay plain dict[str, float] everywhere; provenance is encoded in
# the key as '{section}/{name}' (e.g. 'loss/cross_entropy',
# 'callbacks/accuracy'). `section` adds the prefix at collection time,
# `desection` strips back to leaf names when a consumer wants to match on
# the plain name (early stopping, info_metrics).

def section(metrics: dict[str, float] | None, name: str) -> dict[str, float]:
    """Prefix every key of `metrics` with its provenance section."""
    return {f'{name}/{k}': v for k, v in (metrics or {}).items()}


def desection(metrics: dict[str, float]) -> dict[str, float]:
    """Strip section prefixes, returning leaf-keyed metrics.

    Raises if two sectioned keys share a leaf (e.g. 'loss/accuracy' and
    'callbacks/accuracy'): silently keeping one would let consumers match
    the wrong metric -- rename one of them instead.
    """
    out: dict[str, float] = {}
    origin: dict[str, str] = {}

    for key, val in metrics.items():
        name = key.rsplit('/', 1)[-1]
        if name in out:
            raise KeyError(
                f'metric leaf {name!r} is ambiguous: '
                f'{origin[name]!r} vs {key!r} -- rename one of them'
            )
        out[name] = val
        origin[name] = key

    return out


# -- formatting --------------------------------------------------------------

def wandb_format_metrics(
        metrics: dict[str, Any],
        mode: Literal['train', 'eval', 'test']
        ) -> dict[str, Any]:
    """'loss/cross_entropy' + mode 'train' -> 'train_loss/cross_entropy'.

    wandb panels are sectioned on the prefix before the first '/', so this
    yields sections train_loss, train_optim, eval_callbacks, ... Unsectioned
    keys (e.g. the best_* summary values) fall back to '{mode}/{key}'.
    """
    out = {}
    for key, val in metrics.items():
        if '/' in key:
            sec, name = key.split('/', 1)
            out[f'{mode}_{sec}/{name}'] = val
        else:
            out[f'{mode}/{key}'] = val
    return out


def cmdline_format_metrics(metrics: dict) -> str:

    return '|'.join(
        [f' {m} : {v:.4f} ' for m, v in metrics.items() if isinstance(v, (float, int))]
        )


def wandb_finish(wandb_run: Optional[wandb.Run]) -> None:

    if wandb_run is not None:
        wandb_run.finish()


class MultiAverageMeter:

    def __init__(self):
        self.reset()

    def reset(self):
        self._total = defaultdict(float)
        self._count = defaultdict(float)

    def update(self, metric_dict: dict[str, float], n: int = 1) -> None:
        if n <= 0:
            return

        for metric, val in metric_dict.items():
            if not math.isfinite(val):
                continue

            self._total[metric] += val * n
            self._count[metric] += n

    def get_averages(self) -> dict[str, float]:
        return {
            metric: self._total[metric] / self._count[metric]
            for metric in self._count
            }
