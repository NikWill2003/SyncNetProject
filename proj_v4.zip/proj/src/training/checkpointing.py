from typing import Any, Optional
import math

import torch
import torch.nn as nn
from torch import Tensor
from accelerate import Accelerator

# TODO: when we are doing some longer runs?

class CheckpointingManager:
    ...