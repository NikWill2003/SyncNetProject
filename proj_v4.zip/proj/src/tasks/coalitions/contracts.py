"""The data contract for coalitions: what a batch contains and what a
model returns. Datasets, loaders, models, losses and callbacks are all
annotated against these two types -- if you need to know a key name or
shape, this file is the answer.

Batch tensors all share leading dims (B, T); N = n_modules, K = alphabet
size, P = n undirected pairs.
"""

from __future__ import annotations

from typing import NotRequired, TypedDict

from torch import Tensor


class CoalitionsBatch(TypedDict):
    streams: Tensor      # (B, T, N) long, module token streams
    commands: Tensor     # (B, T) long, command channel (connect/hold/disconnect)
    targets: Tensor      # (B, T, N) long
    loss_mask: Tensor    # (B, T, N) float, 1 where loss/metrics count
    regime: Tensor       # (B, T) long, INDEP/JOINT/POST/READOUT codes
    oracle_adj: Tensor   # (B, T, P) float, required adjacency per pair
    active_gid: Tensor   # (B, T) long, active graph id (EMPTY when none)


class CoalitionsOutput(TypedDict):
    logits: Tensor                    # (B, T, N, K)
    traces: NotRequired[dict]         # return_trace=True only: per-step
                                      # gate matrices, oscillator states
