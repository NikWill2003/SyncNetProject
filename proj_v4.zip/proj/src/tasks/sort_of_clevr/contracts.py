"""The data contract for sort_of_clevr: what a batch contains and what a
model returns. Datasets, loaders, models, losses and callbacks are all
annotated against these two types -- if you need to know a key name or
shape, this file is the answer.
"""

from __future__ import annotations

from typing import NotRequired, TypedDict

from torch import Tensor


class SortOfClevrBatch(TypedDict):
    images: Tensor       # (B, 3, H, W) float
    questions: Tensor    # (B, q_dim) long, one-hot blocks
    answers: Tensor      # (B,) long


class SortOfClevrOutput(TypedDict):
    logits: Tensor                    # (B, answer_dim)
    traces: NotRequired[dict]         # syncnet models only: per-step
                                      # rotors/state and routing attn
