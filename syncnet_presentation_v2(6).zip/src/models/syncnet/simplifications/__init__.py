from .simplifications import SIMPLIFICATIONS
