"""Simplifications: the canonical SyncNet with one part that MIGHT be dispensable removed or
replaced by something simpler. Same mechanics as an ablation (a subclass replacing one seam,
retrained from scratch, selected by `model.simplification=<name>`), different question: an
ablation asks whether a component carries the result, a simplification asks whether a cheaper
version of the model keeps it. Run on Sort-of-CLEVR and SQOOP rhs=1.

Self-contained: replacement modules are defined here; a component is imported only where the
simplification is a specialisation of it (a subclass).
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from ..components.dynamics import PhaseStep
from ..components.pathways import QuestionPathways
from ..components.perception import SeededCompetition
from ..model import SyncNet


# ---- replacement modules ----
class NoEncoderFiLMPathways(QuestionPathways):
    """The question no longer modulates the stem features: perception is question-independent."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        del self.grid_film_gamma, self.grid_film_beta

    def encoder_film(self, f: Tensor, q: Tensor, pos_emb: Tensor) -> Tensor:
        return self.grid_norm(f) + pos_emb


class NoContentFiLMPathways(QuestionPathways):
    """The question no longer modulates the slot contents."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        del self.film_gamma, self.film_beta

    def content_film(self, X: Tensor, q: Tensor) -> Tensor:
        return self.norm(X)


class NoFiLMPathways(QuestionPathways):
    """Both FiLMs gone: the question enters only through the module initialisers and the readout."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        del self.grid_film_gamma, self.grid_film_beta, self.film_gamma, self.film_beta

    encoder_film = NoEncoderFiLMPathways.encoder_film
    content_film = NoContentFiLMPathways.content_film


class NoFrequencyStep(PhaseStep):
    """The natural-frequency rotation removed: phases move only by coupling and stimulus."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        del self.omega, self.gen

    def forward(self, z: Tensor, h: Tensor) -> Tensor:
        B, N, dm = h.shape
        kap = self.k_mlp(torch.cat([h.unsqueeze(2).expand(B, N, N, dm), h.unsqueeze(1).expand(B, N, N, dm)], -1)).squeeze(-1)
        pull = torch.einsum('bij,bjd->bid', self.K.to(z.dtype).unsqueeze(0) * kap, z)
        tangent = lambda v: v - (v * z).sum(-1, keepdim=True) * z
        return F.normalize(z + self.dt * (tangent(pull) + tangent(self.stim(h))), dim=-1)


class CosineCouplingStep(PhaseStep):
    """The pairwise coupling MLP replaced by a signed cosine: kappa_kj = tanh(a cos(Wh_k, Wh_j) + b)."""

    def __init__(self, n_rows: int, module_dim: int, phase_dim: int, kappa_dim: int, dt: float) -> None:
        super().__init__(n_rows, module_dim, phase_dim, kappa_dim, dt)
        del self.k_mlp
        self.proj = nn.Linear(module_dim, kappa_dim, bias=False)
        self.gain, self.offset = nn.Parameter(torch.ones(())), nn.Parameter(torch.zeros(()))

    def forward(self, z: Tensor, h: Tensor) -> Tensor:
        c = F.normalize(self.proj(h), dim=-1)
        kap = torch.tanh(self.gain * torch.einsum('bnc,bmc->bnm', c, c) + self.offset)
        A = self.gen.raw - self.gen.raw.t()
        A = A / (A.norm() / 2 ** 0.5 + 1e-6)
        vel = self.omega.to(z.dtype)[None, :, None] * torch.einsum('de,bne->bnd', A, z)
        pull = torch.einsum('bij,bjd->bid', self.K.to(z.dtype).unsqueeze(0) * kap, z)
        tangent = lambda v: v - (v * z).sum(-1, keepdim=True) * z
        return F.normalize(z + self.dt * (vel + tangent(pull) + tangent(self.stim(h))), dim=-1)


class FixedAnchorCompetition(SeededCompetition):
    """Anchors are the prior means, not samples from the prior (sigma = 0)."""

    def anchors(self, B: int, device, dtype) -> Tensor:
        return F.normalize(self.anchor_mu.to(dtype), dim=-1).expand(B, -1, -1, -1)


class ContentField(nn.Module):
    """No oscillator field: the 'phase' of a cell is its (unit-normalised) feature vector, so the
    competition binds by content rather than by synchrony. K=1 oscillator of dimension field_ch."""

    def __init__(self, field_ch: int) -> None:
        super().__init__()
        self.K, self.d = 1, field_ch

    def forward(self, f: Tensor) -> Tensor:
        return f

    def to_tokens(self, f: Tensor) -> Tensor:
        B, C, S, _ = f.shape
        return F.normalize(f.view(B, C, S * S).transpose(1, 2), dim=-1).unsqueeze(2)     # (B, P, 1, C)


# ---- the suite ----
class NoEncoderFiLM(SyncNet):
    def build_pathways(self, cfg): return NoEncoderFiLMPathways(self.q_size, cfg.field_ch, cfg.tok_dim, cfg.n_modules, cfg.module_dim)


class NoContentFiLM(SyncNet):
    def build_pathways(self, cfg): return NoContentFiLMPathways(self.q_size, cfg.field_ch, cfg.tok_dim, cfg.n_modules, cfg.module_dim)


class NoFiLM(SyncNet):
    def build_pathways(self, cfg): return NoFiLMPathways(self.q_size, cfg.field_ch, cfg.tok_dim, cfg.n_modules, cfg.module_dim)


class NoFrequency(SyncNet):
    def build_dynamics(self, cfg): return NoFrequencyStep(self.N, cfg.module_dim, cfg.phase_dim, cfg.kappa_dim, cfg.dt)


class CosineCoupling(SyncNet):
    def build_dynamics(self, cfg): return CosineCouplingStep(self.N, cfg.module_dim, cfg.phase_dim, cfg.kappa_dim, cfg.dt)


class FixedAnchors(SyncNet):
    def build_binder(self, cfg): return FixedAnchorCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim, cfg.bias_init, cfg.bias_scale, cfg.competition_rounds, cfg.beta)


class OneRound(SyncNet):
    def build_binder(self, cfg): return SeededCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim, cfg.bias_init, cfg.bias_scale, 1, cfg.beta)


class NoField(SyncNet):
    def build_field(self, cfg): return ContentField(cfg.field_ch)


SIMPLIFICATIONS: dict[str, type[SyncNet]] = {
    'no_encoder_film': NoEncoderFiLM, 'no_content_film': NoContentFiLM, 'no_film': NoFiLM,
    'no_frequency': NoFrequency, 'cosine_coupling': CosineCoupling, 'fixed_anchors': FixedAnchors,
    'one_round': OneRound, 'no_field': NoField,
}
