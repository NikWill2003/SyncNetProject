"""Test-time overrides: a trained SyncNet viewed through a subclass with one method
overridden and no parameters of its own, scored by the trainer's evaluate. The drop
against the unmodified model is what the interventions table reports; the test-time
T override reports accuracy as a function of the step count instead.

Self-contained: the views and their callbacks live here. A component is imported only
where a view is a specialisation of it (a subclass).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import torch
import torch.nn as nn
from torch import Tensor

from ...core.callbacks import BaseCallBack, CallbackSpec
from ...core.config import CallbackConfig
from .components.perception import SeededCompetition
from .model import SyncNet

if TYPE_CHECKING:
    from ...core.config import Config


# ---- views ----
class FrozenStep(nn.Module):
    def forward(self, z: Tensor, h: Tensor) -> Tensor:
        return z


class PermutedAnchorCompetition(SeededCompetition):
    """The per-slot anchor priors permuted: is a module addressed by name or by region?"""

    def anchors(self, B: int, device, dtype) -> Tensor:
        return super().anchors(B, device, dtype)[:, torch.randperm(self.n_slots, device=device)]


class FrozenPhase(SyncNet):
    """Trained starting phases, never advanced."""
    def build_dynamics(self, cfg): return FrozenStep()


class ZeroPhase(FrozenPhase):
    """Every module at e_1: addressing removed, messages intact."""
    def initial_phases(self, z_slots, B):
        z = torch.zeros(B, self.N, self.d, device=z_slots.device, dtype=z_slots.dtype)
        z[..., 0] = 1.0
        return z


class ShuffledPhase(SyncNet):
    """The slot rows' starting phases permuted within each sample; the head keeps its own."""
    def initial_phases(self, z_slots, B):
        return super().initial_phases(z_slots[:, torch.randperm(self.M, device=z_slots.device)], B)


class ShuffledAnchors(SyncNet):
    def build_binder(self, cfg):
        return PermutedAnchorCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim, cfg.bias_init, cfg.bias_scale, cfg.competition_rounds, cfg.beta)


def as_(model: SyncNet, view: type[SyncNet]) -> SyncNet:
    """The trained model's weights viewed through an override subclass."""
    m = view(model.cfg, model.dataset, model.answer_dim).to(next(model.parameters()).device)
    m.load_state_dict(model.state_dict(), strict=False)            # views only ever have fewer parts
    return m.eval()


# ---- callbacks: one per override ----
@dataclass
class OverrideCfg(CallbackConfig):
    max_batches: int = 0                                           # 0 = the whole test split


class Override(BaseCallBack):
    view: type[SyncNet]
    key: str

    def __init__(self, max_batches: int = 0) -> None:
        self.max_batches = max_batches

    @classmethod
    def from_config(cls, cfg: Config, cb_cfg: OverrideCfg):
        return cls(max_batches=1 if cfg.logging.preflight else int(cb_cfg.max_batches))

    def on_train_end(self, trainer) -> None:
        model = trainer.unwrapped_model()
        if not isinstance(model, SyncNet) or isinstance(model, self.view):
            return
        base = trainer.evaluate(trainer.test_dataloader, 'test', max_batches=self.max_batches)['callbacks/accuracy']
        hit = trainer.evaluate(trainer.test_dataloader, 'test', model=as_(model, self.view), max_batches=self.max_batches)['callbacks/accuracy']
        trainer.summary({f'override/{self.key}_drop': base - hit}, 'test')


class FreezePhaseOverride(Override):    key, view = 'freeze_phase', FrozenPhase
class ZeroPhaseOverride(Override):      key, view = 'zero_phase', ZeroPhase
class ShufflePhaseOverride(Override):   key, view = 'shuffle_phase', ShuffledPhase
class ShuffleAnchorsOverride(Override): key, view = 'shuffle_anchors', ShuffledAnchors


@dataclass
class TestTimeTOverrideCfg(CallbackConfig):
    t_values: list[int] = field(default_factory=lambda: [1, 2, 4, 6, 8, 12, 14, 16, 18, 24])
    n_repeats: int = 3
    max_batches: int = 8


class TestTimeTOverride(BaseCallBack):
    """The trained model evaluated at other step counts: accuracy as a function of T at test time."""

    def __init__(self, t_values, n_repeats, max_batches) -> None:
        self.t_values, self.n_repeats, self.max_batches = list(t_values), n_repeats, max_batches

    @classmethod
    def from_config(cls, cfg: Config, cb_cfg: TestTimeTOverrideCfg):
        if cfg.logging.preflight:
            return cls([2], 1, 1)
        return cls(cb_cfg.t_values, int(cb_cfg.n_repeats), int(cb_cfg.max_batches))

    def on_train_end(self, trainer) -> None:
        out = {}
        for T in self.t_values:
            accs = [
                trainer.evaluate(trainer.test_dataloader, 'test', max_batches=self.max_batches, t_override=T)['callbacks/accuracy']
                for _ in range(self.n_repeats)
            ]
            out[f't_ramp/acc_mean_T{T}'] = float(np.mean(accs))
            out[f't_ramp/acc_std_T{T}'] = float(np.std(accs))
        trainer.summary(out, 'test')


OVERRIDES: dict[str, CallbackSpec] = {
    **{c.key: CallbackSpec(OverrideCfg, c, requires=frozenset({'sync'}))
       for c in (FreezePhaseOverride, ZeroPhaseOverride, ShufflePhaseOverride, ShuffleAnchorsOverride)},
    'test_time_t_override': CallbackSpec(TestTimeTOverrideCfg, TestTimeTOverride, requires=frozenset({'sync'})),
}
