"""Every class is the canonical SyncNet with exactly one component replaced, selected by
`model.ablation=<name>` and retrained from scratch under the protocol.

Self-contained: the replacement modules are defined here. A component is imported only
where the ablation is a specialisation of it (a subclass), never to be reused as is.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from .components.perception import SeededCompetition
from .components.readout import HeadReadout
from .model import SyncNet


# ---- replacement modules ----
class SilentMedium(nn.Module):
    """No medium: the floor. Same output width so the cells are unchanged."""

    def __init__(self, out_dim: int) -> None:
        super().__init__()
        self.out_dim = out_dim

    def forward(self, h: Tensor, z: Tensor) -> Tensor:
        return h.new_zeros(h.shape[0], h.shape[1], self.out_dim)


class AttentionMedium(nn.Module):
    """Per-sender access with a content gate: the content-routing alternative to the bus."""

    def __init__(self, module_dim: int, msg_dim: int) -> None:
        super().__init__()
        self.msg_proj = nn.Linear(module_dim, msg_dim)
        self.q, self.k = nn.Linear(module_dim, module_dim), nn.Linear(module_dim, module_dim)
        self.out_dim = msg_dim

    def forward(self, h: Tensor, z: Tensor) -> Tensor:
        N = h.shape[1]
        att = torch.einsum('bnd,bmd->bnm', self.q(h), self.k(h)) / h.shape[-1] ** 0.5
        att = att.masked_fill(torch.eye(N, dtype=torch.bool, device=h.device), float('-inf')).softmax(-1)
        return torch.einsum('bnm,bmD->bnD', att, self.msg_proj(h))


class IdentityStep(nn.Module):
    """Phases do not move."""

    def forward(self, z: Tensor, h: Tensor) -> Tensor:
        return z


class SharedCell(nn.Module):
    """One GRU for every module; identity only through the embeddings."""

    def __init__(self, in_dim: int, module_dim: int, n_modules: int) -> None:
        super().__init__()
        self.cell = nn.GRUCell(in_dim, module_dim)
        self.embeds = nn.Parameter(torch.randn(n_modules, module_dim) / module_dim ** 0.5)

    def step(self, inp: Tensor, h: Tensor) -> Tensor:
        B, N, dm = h.shape
        return self.cell(inp.reshape(B * N, -1), h.reshape(B * N, dm)).reshape(B, N, dm)


class UnseededCompetition(SeededCompetition):
    """The competition without its spatial bias: b_k(p) = 0 and not learned."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        del self.cell_bias

    def bias(self) -> Tensor:
        return torch.zeros((), device=self.prior_scale.device, dtype=self.prior_scale.dtype)


class SharedAnchorCompetition(SeededCompetition):
    """One anchor prior for every slot: identity by seeding region alone."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.anchor_mu = nn.Parameter(self.anchor_mu[:, :1].clone())
        self.anchor_log_sigma = nn.Parameter(self.anchor_log_sigma[:, :1].clone())

    def anchors(self, B: int, device, dtype) -> Tensor:
        eps = torch.randn(B, self.n_slots, self.groups, self.osc_dim, device=device, dtype=dtype)
        return F.normalize(self.anchor_mu + self.anchor_log_sigma.exp() * eps, dim=-1)


class PriorHeadReadout(HeadReadout):
    """The readout plus a question-only term: a path to the answer that bypasses the medium."""

    def __init__(self, module_dim: int, q_size: int, answer_dim: int, hidden: int) -> None:
        super().__init__(module_dim, q_size, answer_dim, hidden)
        self.prior_head = nn.Sequential(nn.Linear(q_size, hidden), nn.GELU(), nn.Linear(hidden, answer_dim))

    def forward(self, h_head: Tensor, q: Tensor) -> Tensor:
        return super().forward(h_head, q) + self.prior_head(q)


# ---- the suite ----
class Silent(SyncNet):
    def build_medium(self, cfg):   return SilentMedium(cfg.msg_dim * cfg.phase_dim)


class LinesAttention(SyncNet):
    def build_medium(self, cfg):   return AttentionMedium(cfg.module_dim, cfg.msg_dim)


class StaticAddresses(SyncNet):
    """Phases fixed to learned per-module vectors: capacity kept, dynamics removed."""

    def __init__(self, cfg, dataset, answer_dim):
        super().__init__(cfg, dataset, answer_dim)
        self.z_static = nn.Parameter(F.normalize(torch.randn(self.N, cfg.phase_dim), dim=-1))

    def build_dynamics(self, cfg): return IdentityStep()

    def initial_phases(self, z_slots, B):
        return F.normalize(self.z_static, dim=-1).expand(B, -1, -1).to(z_slots.dtype)


class SharedCells(SyncNet):
    def build_cells(self, cfg):    return SharedCell(cfg.tok_dim + self.medium.out_dim, cfg.module_dim, cfg.n_modules)


class SharedAnchors(SyncNet):
    def build_binder(self, cfg):   return SharedAnchorCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim, cfg.bias_init, cfg.bias_scale, cfg.competition_rounds, cfg.beta)


class NoBias(SyncNet):
    def build_binder(self, cfg):   return UnseededCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim, 'zero', 0.0, cfg.competition_rounds, cfg.beta)


class HardPartition(SyncNet):
    def build_binder(self, cfg):   return SeededCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim, 'partition', 50.0, cfg.competition_rounds, cfg.beta)


class WithPriorTerm(SyncNet):
    def build_readout(self, cfg):  return PriorHeadReadout(cfg.module_dim, self.q_size, self.answer_dim, cfg.readout_hidden)


ABLATIONS: dict[str | None, type[SyncNet]] = {
    None: SyncNet, 'silent': Silent, 'lines_attention': LinesAttention, 'static_addresses': StaticAddresses,
    'shared_cells': SharedCells, 'shared_anchors': SharedAnchors, 'no_bias': NoBias, 'hard_partition': HardPartition,
    'with_prior_term': WithPriorTerm,
}
