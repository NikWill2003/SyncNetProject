"""The SyncNet. One model, read top to bottom against Chapter 3: a shared cnn stem,
an oscillator field that binds cells into slots by phase, M private modules and a
question-only head that exchange messages over one phase-addressed bus for T steps,
and an answer read from the head alone.

No flags. An ablation is a subclass that replaces one component (ablations.py); a
test-time override is a subclass with no parameters of its own (overrides.py). The
only forward argument beyond the batch is t_override, the test-time step count.
Task-dependent sizes come from the task's spec; everything else is in the config.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from ..common.img_enc import build_image_encoder
from ...core.config import ModelConfig
from ...tasks import DATASETS
from .components import (
    AdaptedStem,
    Bus,
    HeadReadout,
    OscillatorField,
    PhaseStep,
    PrivateCells,
    QuestionPathways,
    SeededCompetition,
    )


@dataclass
class SyncNetConfig(ModelConfig):
    name: str = 'syncnet'
    ablation: str | None = None                                    # None | a key of ablations.ABLATIONS
    simplification: str | None = None                              # None | a key of simplifications.SIMPLIFICATIONS
    encoder: dict[str, Any] = field(default_factory=lambda: {'name': 'cnn', 'ch': 64})

    # the modules and their medium
    n_modules: int = 6
    phase_dim: int = 6
    t_bus: int = 8
    dt: float = 0.5
    module_dim: int = 96
    msg_dim: int = 4
    kappa_dim: int = 64
    readout_hidden: int = 128

    # the field and the competition
    field_ch: int = 64                                             # channels the field reads (1x1 adapter from the stem)
    field_groups: int = 16                                         # oscillators per cell
    field_osc_dim: int = 4                                         # dimension of each cell oscillator
    field_steps: int = 8                                           # T_x
    field_dt: float = 1.0                                          # gamma_x
    tok_dim: int = 64                                              # slot content width
    beta: float = 8.0                                              # competition inverse temperature (initial, learned)
    bias_init: str = 'zero'                                        # zero | partition | random
    bias_scale: float = 4.0
    competition_rounds: int = 3


class SyncNet(nn.Module):
    supported_callbacks = frozenset({'sync'})

    def __init__(self, cfg: SyncNetConfig, dataset: str, answer_dim: int) -> None:
        super().__init__()
        self.cfg, self.dataset, self.answer_dim = cfg, dataset, answer_dim
        spec = DATASETS[dataset]
        self.q_vocab = getattr(spec, 'VOCAB_SIZE', None)             # token questions are one-hot encoded; vector questions pass through
        self.q_size = spec.QUESTION_SIZE * (self.q_vocab or 1)
        self.M, self.N, self.d, self.T = cfg.n_modules, cfg.n_modules + 1, cfg.phase_dim, cfg.t_bus

        self.field_enc = AdaptedStem(build_image_encoder(dict(cfg.encoder), dataset), cfg.field_ch)
        S = self.field_enc.spatial
        self.n_cells = S * S
        self.pos_emb = nn.Parameter(0.02 * torch.randn(1, cfg.field_ch, S, S))
        self.field = self.build_field(cfg)
        self.binder = self.build_binder(cfg)
        self.anchor_to_phase = nn.Linear(self.field.K * self.field.d, cfg.phase_dim)
        self.pathways = self.build_pathways(cfg)
        self.medium = self.build_medium(cfg)
        self.identity = self.build_cells(cfg)
        self.dynamics = self.build_dynamics(cfg)
        self.readout = self.build_readout(cfg)

    # ---- seams: one method per component an ablation or simplification may replace ----
    def build_field(self, cfg: SyncNetConfig) -> nn.Module:
        return OscillatorField(cfg.field_ch, cfg.field_groups, cfg.field_osc_dim, cfg.field_steps, cfg.field_dt)

    def build_pathways(self, cfg: SyncNetConfig) -> nn.Module:
        return QuestionPathways(self.q_size, cfg.field_ch, cfg.tok_dim, cfg.n_modules, cfg.module_dim)

    def build_binder(self, cfg: SyncNetConfig) -> nn.Module:
        return SeededCompetition(cfg.n_modules, self.n_cells, cfg.field_ch, self.field.K, self.field.d, cfg.tok_dim,
                                 cfg.bias_init, cfg.bias_scale, cfg.competition_rounds, cfg.beta)

    def build_medium(self, cfg: SyncNetConfig) -> nn.Module:
        return Bus(cfg.module_dim, cfg.msg_dim, cfg.phase_dim)

    def build_cells(self, cfg: SyncNetConfig) -> nn.Module:
        return PrivateCells(self.N, cfg.tok_dim + self.medium.out_dim, cfg.module_dim, cfg.n_modules)

    def build_dynamics(self, cfg: SyncNetConfig) -> nn.Module:
        return PhaseStep(self.N, cfg.module_dim, cfg.phase_dim, cfg.kappa_dim, cfg.dt)

    def build_readout(self, cfg: SyncNetConfig) -> nn.Module:
        return HeadReadout(cfg.module_dim, self.q_size, self.answer_dim, cfg.readout_hidden)

    def initial_phases(self, z_slots: Tensor, B: int) -> Tensor:
        z = F.normalize(torch.randn(B, self.N, self.d, device=z_slots.device, dtype=z_slots.dtype), dim=-1)
        return torch.cat([z_slots, z[:, self.M:]], 1)             # slots start from their anchors, the head from a draw

    # ---- the computation ----
    def encode_question(self, questions: Tensor) -> Tensor:
        if self.q_vocab:
            return F.one_hot(questions.long(), self.q_vocab).float().flatten(-2)
        return questions.float()

    def forward(self, batch: dict, t_override: int | None = None, **_: Any) -> dict:
        q = self.encode_question(batch['questions'])
        B = q.shape[0]

        f = self.pathways.encoder_film(self.field_enc(batch['images']), q, self.pos_emb)
        Zt = self.field.to_tokens(self.field(f))
        X, anchors = self.binder(f.flatten(2).transpose(1, 2), Zt)
        z = self.initial_phases(F.normalize(self.anchor_to_phase(anchors.flatten(2)), dim=-1), B)
        X = self.pathways.content_film(X, q)

        h_slots, h_head = self.pathways.init_states(q)
        h = torch.cat([h_slots + self.identity.embeds.unsqueeze(0), h_head], 1)
        X = torch.cat([X, X.new_zeros(B, 1, X.shape[-1])], 1)     # the head has no view of the image

        for _ in range(self.T if t_override is None else int(t_override)):
            h = self.identity.step(torch.cat([X, self.medium(h, z)], -1), h)
            z = self.dynamics(z, h)
        return {'logits': self.readout(h[:, self.M], q)}

    @classmethod
    def from_config(cls, cfg: SyncNetConfig, dataset: str, answer_dim: int) -> 'SyncNet':
        return cls(cfg, dataset, answer_dim)
