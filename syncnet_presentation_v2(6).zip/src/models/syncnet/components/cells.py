from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class PrivateCells(nn.Module):
    def __init__(self, n_rows: int, in_dim: int, module_dim: int, n_modules: int) -> None:
        super().__init__()
        self.cells = nn.ModuleList(nn.GRUCell(in_dim, module_dim) for _ in range(n_rows))
        self.embeds = nn.Parameter(torch.randn(n_modules, module_dim) / module_dim ** 0.5)

    def step(self, inp: Tensor, h: Tensor) -> Tensor:
        return torch.stack([cell(inp[:, k], h[:, k]) for k, cell in enumerate(self.cells)], 1)


