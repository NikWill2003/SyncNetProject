from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class PhaseStep(nn.Module):
    """z_k <- Pi( z_k + gamma( omega_k A z_k + Proj_z( sum_j J_kj tanh(MLP[h_k;h_j]) z_j + W_c h_k ) ) )."""

    def __init__(self, n_rows: int, module_dim: int, phase_dim: int, kappa_dim: int, dt: float) -> None:
        super().__init__()
        self.dt = dt
        self.omega = nn.Parameter(torch.zeros(n_rows))
        self.K = nn.Parameter(torch.ones(n_rows, n_rows))
        self.k_mlp = nn.Sequential(nn.Linear(2 * module_dim, kappa_dim), nn.GELU(), nn.Linear(kappa_dim, 1), nn.Tanh())
        self.stim = nn.Linear(module_dim, phase_dim)
        self.gen = nn.Module()
        self.gen.raw = nn.Parameter(0.1 * torch.randn(phase_dim, phase_dim))

    def forward(self, z: Tensor, h: Tensor) -> Tensor:
        B, N, dm = h.shape
        A = self.gen.raw - self.gen.raw.t()
        A = A / (A.norm() / math.sqrt(2) + 1e-6)
        vel = self.omega.to(z.dtype)[None, :, None] * torch.einsum('de,bne->bnd', A, z)
        kap = self.k_mlp(torch.cat([h.unsqueeze(2).expand(B, N, N, dm), h.unsqueeze(1).expand(B, N, N, dm)], -1)).squeeze(-1)
        pull = torch.einsum('bij,bjd->bid', self.K.to(z.dtype).unsqueeze(0) * kap, z)
        tangent = lambda v: v - (v * z).sum(-1, keepdim=True) * z
        return F.normalize(z + self.dt * (vel + tangent(pull) + tangent(self.stim(h))), dim=-1)


