from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor


class QuestionPathways(nn.Module):
    """Every pathway by which the question reaches the computation, in one place:
    FiLM on the stem features, FiLM on the slot contents, and the state initialisers."""

    def __init__(self, q_size: int, field_ch: int, tok_dim: int, n_modules: int, module_dim: int) -> None:
        super().__init__()
        self.grid_film_gamma, self.grid_film_beta = nn.Linear(q_size, field_ch), nn.Linear(q_size, field_ch)
        self.grid_norm = nn.GroupNorm(8, field_ch, affine=True)
        self.film_gamma, self.film_beta, self.norm = nn.Linear(q_size, tok_dim), nn.Linear(q_size, tok_dim), nn.LayerNorm(tok_dim)
        self.h_init = nn.Sequential(nn.Linear(q_size, 64), nn.GELU(), nn.Linear(64, n_modules * module_dim))
        self.head_init = nn.Sequential(nn.Linear(q_size, 64), nn.GELU(), nn.Linear(64, module_dim))
        self.head_embed = nn.Parameter(torch.randn(1, module_dim) / module_dim ** 0.5)
        self.n_modules, self.module_dim = n_modules, module_dim

    def encoder_film(self, f: Tensor, q: Tensor, pos_emb: Tensor) -> Tensor:
        return self.grid_norm(f * (1 + self.grid_film_gamma(q))[..., None, None] + self.grid_film_beta(q)[..., None, None]) + pos_emb

    def content_film(self, X: Tensor, q: Tensor) -> Tensor:
        return self.norm(X * (1 + self.film_gamma(q)).unsqueeze(1) + self.film_beta(q).unsqueeze(1))

    def init_states(self, q: Tensor) -> tuple[Tensor, Tensor]:
        return self.h_init(q).reshape(q.shape[0], self.n_modules, self.module_dim), self.head_init(q).unsqueeze(1) + self.head_embed.unsqueeze(0)
