from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class HeadReadout(nn.Module):
    def __init__(self, module_dim: int, q_size: int, answer_dim: int, hidden: int) -> None:
        super().__init__()
        self.head_out = nn.Sequential(nn.Linear(module_dim + q_size, hidden), nn.GELU(), nn.Linear(hidden, answer_dim))

    def forward(self, h_head: Tensor, q: Tensor) -> Tensor:
        return self.head_out(torch.cat([h_head, q], -1))


