from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class AdaptedStem(nn.Module):
    """The task's shared cnn stem, adapted to the field by a 1x1 conv to `field_ch` channels."""

    def __init__(self, base: nn.Module, field_ch: int) -> None:
        super().__init__()
        self.base, self.adapt, self.spatial = base, nn.Conv2d(base.ch, field_ch, 1), base.spatial

    def forward(self, x: Tensor) -> Tensor:
        return self.adapt(self.base(x))


class OscillatorField(nn.Module):
    """`groups` unit `osc_dim`-vectors per cell, evolved `steps` Euler steps of natural rotation
    + 5x5 conv coupling + feature stimulus, tangent-projected and renormalised."""

    def __init__(self, field_ch: int, groups: int, osc_dim: int, steps: int, dt: float) -> None:
        super().__init__()
        self.d, self.K, self.C, self.T, self.dt = osc_dim, groups, osc_dim * groups, steps, dt
        self.z_head, self.stim = nn.Conv2d(field_ch, self.C, 1), nn.Conv2d(field_ch, self.C, 1)
        self.J = nn.Conv2d(self.C, self.C, 5, padding=2, bias=False)
        nn.init.normal_(self.J.weight, std=0.02)
        self.omega_raw = nn.Parameter(torch.randn(groups, osc_dim, osc_dim) * 0.1)
        self.omega_scale = 0.1

    def normalise(self, z: Tensor) -> Tensor:
        B, C, S, _ = z.shape
        return F.normalize(z.view(B, self.K, self.d, S, S), dim=2).view(B, C, S, S)

    def tangent(self, z: Tensor, v: Tensor) -> Tensor:
        B, C, S, _ = z.shape
        zg, vg = z.view(B, self.K, self.d, S, S), v.view(B, self.K, self.d, S, S)
        return (vg - (vg * zg).sum(2, keepdim=True) * zg).reshape(B, C, S, S)

    def rotate(self, z: Tensor) -> Tensor:
        B, C, S, _ = z.shape
        A = (self.omega_raw - self.omega_raw.transpose(-1, -2)) * self.omega_scale
        return torch.einsum('kde,bkeij->bkdij', A, z.view(B, self.K, self.d, S, S)).reshape(B, C, S, S)

    def to_tokens(self, z: Tensor) -> Tensor:
        B, C, S, _ = z.shape
        return z.view(B, self.K, self.d, S * S).permute(0, 3, 1, 2)          # (B, P, K, d)

    def forward(self, f: Tensor) -> Tensor:
        z, c = self.normalise(self.z_head(f)), self.stim(f)
        for _ in range(self.T):
            z = self.normalise(z + self.dt * (self.rotate(z) + self.tangent(z, self.J(z) + c)))
        return z


class SeededCompetition(nn.Module):
    """Cells choose one slot each (softmax over slots) by phase alignment with a per-slot anchor
    sampled from a learned prior, seeded by the spatial bias b_k(p); anchors refine over `rounds`."""

    def __init__(self, n_slots: int, n_cells: int, field_ch: int, groups: int, osc_dim: int, tok_dim: int,
                 bias_init: str, bias_scale: float, rounds: int, beta: float) -> None:
        super().__init__()
        self.n_slots, self.iters, self.groups, self.osc_dim = n_slots, rounds, groups, osc_dim
        self.cell_bias = nn.Parameter(self.seed_bias(n_slots, n_cells, bias_init, bias_scale))
        self.register_buffer('prior_scale', torch.ones(()))
        self.anchor_mu = nn.Parameter(torch.randn(1, n_slots, groups, osc_dim))
        self.anchor_log_sigma = nn.Parameter(torch.zeros(1, n_slots, groups, osc_dim))
        self.log_beta = nn.Parameter(torch.log(torch.tensor(beta)))
        self.to_slot = nn.Sequential(nn.LayerNorm(field_ch), nn.Linear(field_ch, tok_dim))

    @staticmethod
    def seed_bias(n_slots: int, n_cells: int, bias_init: str, bias_scale: float) -> Tensor:
        bias = torch.zeros(n_slots, n_cells)
        S = int(round(n_cells ** 0.5))
        if bias_init == 'partition':                                           # one grid region per slot
            rows = max(1, int(n_slots ** 0.5)); cols = -(-n_slots // rows)
            ys = torch.arange(S).repeat_interleave(S); xs = torch.arange(S).repeat(S)
            region = (ys * rows // S) * cols + (xs * cols // S)
            for k in range(min(n_slots, rows * cols)):
                bias[k, region == k] = bias_scale
        elif bias_init == 'random':                                            # random regions, fixed seed
            region = torch.randint(0, n_slots, (n_cells,), generator=torch.Generator().manual_seed(0))
            for k in range(n_slots):
                bias[k, region == k] = bias_scale
        elif bias_init != 'zero':
            raise ValueError(f'unknown bias_init {bias_init!r}')
        return bias

    def anchors(self, B: int, device, dtype) -> Tensor:
        """One anchor per slot, drawn from its prior."""
        eps = torch.randn(B, self.n_slots, self.groups, self.osc_dim, device=device, dtype=dtype)
        return F.normalize(self.anchor_mu + self.anchor_log_sigma.exp() * eps, dim=-1)

    def bias(self) -> Tensor:
        return self.prior_scale * self.cell_bias

    def forward(self, feats: Tensor, Zt: Tensor) -> tuple[Tensor, Tensor]:
        """feats (B, P, field_ch); Zt (B, P, K, d) -> slot contents (B, M, tok_dim), anchors (B, M, K, d)."""
        B, K_f = feats.shape[0], Zt.shape[2]
        phi = self.anchors(B, feats.device, feats.dtype)
        for _ in range(self.iters):
            logits = self.log_beta.exp() * torch.einsum('bkgd,bngd->bkn', phi, Zt) / K_f + self.bias()
            reads = F.softmax(logits, dim=1)                                    # cells choose slots
            reads = reads / (reads.sum(-1, keepdim=True) + 1e-8)
            phi = F.normalize(torch.einsum('bkn,bngd->bkgd', reads, Zt), dim=-1)
            slots = self.to_slot(torch.einsum('bkn,bnf->bkf', reads, feats))
        return slots, phi
