from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


class Frame:
    def __init__(self, phase_dim: int, seed: int = 1234) -> None:
        g = torch.Generator().manual_seed(seed)
        self.ref = F.normalize(torch.randn(phase_dim - 1, phase_dim, generator=g), dim=-1)

    def __call__(self, z: Tensor) -> Tensor:
        vecs = [z]
        for k in range(z.shape[-1] - 1):
            v = self.ref[k].to(z).expand_as(z)
            for u in vecs:
                v = v - (v * u).sum(-1, keepdim=True) * u
            vecs.append(F.normalize(v, dim=-1))
        return torch.stack(vecs, 2)


class Bus(nn.Module):
    def __init__(self, module_dim: int, message_dim: int, phase_dim: int) -> None:
        super().__init__()
        self.msg_proj = nn.Linear(module_dim, message_dim)
        self.frame = Frame(phase_dim)
        self.register_buffer('frame_ref', self.frame.ref.clone())
        self.out_dim = message_dim * phase_dim

    def forward(self, h: Tensor, z: Tensor) -> Tensor:
        m = self.msg_proj(h)
        bus = torch.einsum('bnD,bnd->bDd', m, z)
        Q = self.frame(z)
        r = torch.einsum('bDd,bnad->bnDa', bus, Q) - torch.einsum('bnD,bnd,bnad->bnDa', m, z, Q)
        return r.flatten(2) / h.shape[1]


