#!/usr/bin/env python3
"""Is 0.5 (or 0.25) of a GPU per run the right share on THIS box? Launch 1/share concurrent
copies of the real training step -- the experiment's model, compile settings, and the real
dataloader path with the loader workers the share would get -- on one GPU, and report the
throughput each copy gets, the total per GPU, peak memory against the card, and whether the
CPU side keeps up. The verdict for each share is FITS / CPU-BOUND / OOM.
    python scripts/bench_gpu_share.py task=sqoop experiment=sqoop/syncnet
    python scripts/bench_gpu_share.py task=sqoop experiment=sqoop/syncnet --shares 1,0.5,0.25 --steps 60
Needs the experiment's default split on disk (prepared first) and one GPU; ~5 minutes.
"""
from __future__ import annotations
import argparse, json, os, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

WORKER = r'''
import os, sys, time, json, torch
sys.path.insert(0, %(root)r)
from hydra import compose, initialize_config_dir
from src.core.registry import register_configs, build_model, build_loss_fn, build_dataloaders
from src.utils import set_torch_config
register_configs()
overrides = %(overrides)r
with initialize_config_dir(config_dir=os.path.join(%(root)r, 'conf'), version_base='1.3'):
    cfg = compose(config_name='config', overrides=overrides + ['hydra.mode=RUN'])
set_torch_config('cuda'); torch.set_num_threads(%(threads)d)
loaders = build_dataloaders(cfg, 'cuda')
model = build_model(cfg).cuda()
if cfg.train.channels_last: model = model.to(memory_format=torch.channels_last)
if cfg.train.compile_model: model = torch.compile(model, mode=cfg.train.compile_mode)
loss_fn = build_loss_fn(cfg); opt = torch.optim.AdamW(model.parameters(), lr=3e-4, fused=True)
def step(batch):
    with torch.autocast('cuda', dtype=torch.bfloat16):
        loss, _ = loss_fn(model(batch), batch)
    loss.backward(); opt.step(); opt.zero_grad(set_to_none=True)
it = iter(loaders[0]); n = 0
for _ in range(5): step(next(it))                               # warm-up (compile)
torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats(); t0 = time.perf_counter(); wait = 0.0
for _ in range(%(steps)d):
    tw = time.perf_counter(); batch = next(it); wait += time.perf_counter() - tw   # time spent waiting for data
    step(batch); n += batch['answers'].shape[0]
torch.cuda.synchronize(); dt = time.perf_counter() - t0
print('RESULT ' + json.dumps({'ex_s': n / dt, 'wait_frac': wait / dt, 'peak_gb': torch.cuda.max_memory_allocated() / 2**30}))
'''


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('overrides', nargs='+', help='task=... experiment=... [more]')
    ap.add_argument('--shares', default='1,0.5,0.25'); ap.add_argument('--steps', type=int, default=60); ap.add_argument('--gpu', default='0')
    args = ap.parse_args()
    import torch
    total_gb = torch.cuda.get_device_properties(int(args.gpu)).total_memory / 2**30
    cores, gpus = os.cpu_count() or 1, max(torch.cuda.device_count(), 1)
    print(f'{torch.cuda.get_device_name(int(args.gpu))} ({total_gb:.0f} GB), {gpus} GPU(s), {cores} cores; {args.steps} timed steps per copy')
    overrides = list(args.overrides) + ['train.loader_mode=dataloader']
    verdicts, totals = {}, {}
    for share in [float(s) for s in args.shares.split(',')]:
        k = max(int(round(1 / share)), 1)
        cpus = max(cores // (gpus * k), 1); workers = max(min(cpus - 1, 3), 0)
        env = {**os.environ, 'CUDA_VISIBLE_DEVICES': args.gpu, 'OMP_NUM_THREADS': str(cpus)}
        code = WORKER % {'root': ROOT, 'overrides': overrides + [f'train.num_workers={workers}'], 'threads': cpus, 'steps': args.steps}
        procs = [subprocess.Popen([sys.executable, '-c', code], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for _ in range(k)]
        results = []
        for p in procs:
            out, err = p.communicate()
            line = [l for l in out.splitlines() if l.startswith('RESULT ')]
            results.append(json.loads(line[0][7:]) if line else {'error': (err.strip().splitlines() or ['?'])[-1][:120]})
        ok = [r for r in results if 'error' in r] == []
        if not ok:
            verdicts[share] = 'OOM/ERROR'
            print(f'\nshare {share}: {k} copies -> {[r.get("error") for r in results if "error" in r][0]}')
            continue
        per = sum(r['ex_s'] for r in results) / k; total = sum(r['ex_s'] for r in results)
        peak = sum(r['peak_gb'] for r in results); wait = max(r['wait_frac'] for r in results)
        fits = peak * 1.15 < total_gb                                       # 15% headroom for allocator fragmentation
        cpu_bound = wait > 0.2
        verdicts[share] = 'FITS' if fits and not cpu_bound else ('OOM-RISK' if not fits else 'CPU-BOUND')
        print(f'\nshare {share}: {k} copies x ({cpus} cores, {workers} loader workers) each')
        totals[share] = total
        print(f'   per copy {per:7.0f} ex/s   total per GPU {total:7.0f} ex/s   peak memory {peak:5.1f} / {total_gb:.0f} GB   data wait {100*wait:4.1f}%   wall x{totals[max(totals)] / per:.1f} per run   -> {verdicts[share]}')
    # a smaller share earns its longer per-run wall time only if it adds >= 15% total throughput
    # over the next larger share that fits
    best = None
    for share in sorted((s for s, v in verdicts.items() if v == 'FITS'), reverse=True):
        if best is None or totals[share] >= 1.15 * totals[best]:
            best = share
    print(f'\nverdict: ' + (f'use hydra.launcher.ray.remote.num_gpus={best}  (--workers-per-gpu {int(round(1 / best))})' if best else 'no share fits; use 1.0 with gpu_cached, or a bigger card'))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
