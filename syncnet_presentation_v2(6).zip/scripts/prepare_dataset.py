import hydra

from src.core import Config, register_configs
from src.core.registry import prepare_dataset

register_configs()


@hydra.main(config_path='../conf', config_name='prepare', version_base='1.3')
def main(cfg: Config) -> None:
    """Generate one dataset. For every split a sweep will need, sweep the dataset keys with -m:
        python -m scripts.prepare_dataset -m task=sqoop dataset.rhs_variety=1,2,4,8,18,35
    (add `-cn prepare_parallel` to generate them concurrently through Ray)."""
    prepare_dataset(cfg)


if __name__ == '__main__':
    main()
