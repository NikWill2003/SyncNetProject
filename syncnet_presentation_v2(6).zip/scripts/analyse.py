#!/usr/bin/env python3
"""Post-hoc analysis of a saved SyncNet run: the same override and T-ramp callbacks the
training run uses, applied to a checkpoint, written to CSV.
    python scripts/analyse.py outputs/sqoop/<run>/best_model.pt --csv results/analysis.csv
The run directory must hold the resolved config (.hydra/config.yaml) next to the checkpoint.
"""
from __future__ import annotations
import argparse, csv, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import torch
from omegaconf import OmegaConf
from src.core.registry import build_dataloaders, build_loss_fn, build_model, register_configs
from src.models.syncnet.overrides import TestTimeTOverride
from src.models.syncnet.overrides import OVERRIDES


class _Trainer:
    """Just enough of the Trainer for the callbacks: evaluate(), summary(), the test loader."""

    def __init__(self, cfg, model, loaders):
        from src.core.registry import build_callbacks
        self.cfg, self.model, self.test_dataloader = cfg, model, loaders[-1]
        self.callbacks, self.loss_fn, self.out = build_callbacks(OmegaConf.create({**OmegaConf.to_container(cfg), 'callbacks': []}), model), build_loss_fn(cfg), {}

    def unwrapped_model(self): return self.model
    def summary(self, metrics, mode): self.out.update(metrics)

    @torch.no_grad()
    def evaluate(self, loader, mode, model=None, max_batches=0, **fwd):
        model = (model or self.model).eval(); hit = n = 0
        for i, batch in enumerate(iter(loader)):
            if max_batches and i >= max_batches: break
            out = model(batch, **fwd); hit += (out['logits'].argmax(-1) == batch['answers']).sum().item(); n += batch['answers'].numel()
        return {'callbacks/accuracy': hit / max(n, 1)}


def main() -> int:
    ap = argparse.ArgumentParser(); ap.add_argument('checkpoint'); ap.add_argument('--csv', default='results/analysis.csv'); ap.add_argument('--max-batches', type=int, default=0)
    args = ap.parse_args(); register_configs()
    run_dir = os.path.dirname(args.checkpoint)
    cfg = OmegaConf.load(os.path.join(run_dir, '.hydra', 'config.yaml'))
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = build_model(cfg).to(device); model.load_state_dict(torch.load(args.checkpoint, map_location=device)); model.eval()
    t = _Trainer(cfg, model, build_dataloaders(cfg, device))
    for key, spec in OVERRIDES.items():
        if hasattr(spec.callback_class, 'view'): spec.callback_class(max_batches=args.max_batches).on_train_end(t)
    TestTimeTOverride([1, 2, 4, 6, 8, 12, 16], 3, args.max_batches or 8).on_train_end(t)
    os.makedirs(os.path.dirname(args.csv), exist_ok=True)
    with open(args.csv, 'a', newline='') as f:
        w = csv.writer(f); w.writerow(['checkpoint', *t.out]); w.writerow([args.checkpoint, *[f'{v:.4f}' for v in t.out.values()]])
    print({k: round(v, 4) for k, v in t.out.items()}); return 0


if __name__ == '__main__':
    raise SystemExit(main())
