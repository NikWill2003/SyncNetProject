import os
import torch
import hydra
from hydra.core.hydra_config import HydraConfig
from accelerate.logging import get_logger
from omegaconf import OmegaConf

from .main import build_components

from src.core import Config, register_configs
from src.training import Trainer


def runs_per_box(gpu_share: float) -> int:
    """How many runs Ray will place on this box: one per `gpu_share` of each GPU."""
    return max(int(round(max(torch.cuda.device_count(), 1) / float(gpu_share))), 1)


def auto_num_cpus(gpu_share: float) -> int:
    """CPU cores reserved per run so that the box's cores split evenly across the runs
    that share its GPUs. Ray also sets OMP_NUM_THREADS to this, so CPU-side torch ops
    of concurrent runs do not fight over the same cores."""
    return max((os.cpu_count() or 1) // runs_per_box(gpu_share), 1)


def auto_num_workers(gpu_share: float, cap: int = 3) -> int:
    """Loader workers per run: its reserved cores minus one for the training process, capped.
    A worker only slices the memory-mapped split (the float cast happens on the device), so
    two or three keep a 4090 fed; more just adds processes. Ignored in gpu_cached mode."""
    return max(min(auto_num_cpus(gpu_share) - 1, cap), 0)


OmegaConf.register_new_resolver('auto_num_cpus', auto_num_cpus)
OmegaConf.register_new_resolver('auto_num_workers', auto_num_workers)

register_configs()

logger = get_logger(__name__)


@hydra.main(config_path='../conf', config_name='config_parallel', version_base='1.3')
def main(cfg: Config) -> float:

    job = HydraConfig.get().job.get('override_dirname') or HydraConfig.get().job.name
    results_log = cfg.logging.results_log or os.environ.get('SYNCNET_RESULTS_LOG')
    try:
        components = build_components(cfg)
        try:
            trainer = Trainer(cfg=cfg, logger=logger, **components)
            final_metrics = trainer.train()
        finally:
            components['accelerator'].end_training()
    except Exception:
        _report(job, False, results_log)
        raise
    _report(job, True, results_log)
    return float(final_metrics.get(f'best_{cfg.train.early_stop_metric}', 0.0))


def _report(job: str, ok: bool, path: str | None) -> None:
    """One ok/FAIL line per job for the campaign bridge (logging.results_log), and a marker file."""
    out_dir = HydraConfig.get().runtime.output_dir
    open(os.path.join(out_dir, 'RUN_SUCCESS' if ok else 'RUN_FAILED'), 'w').close()
    if path:
        with open(path, 'a') as f:
            f.write(f"{'ok  ' if ok else 'FAIL'} {job}\n")


if __name__ == '__main__':
    main()
