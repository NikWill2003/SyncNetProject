#!/usr/bin/env python3
"""Time one optimiser step of an experiment under the speed settings, on whatever device is
present, so the choice is made from a measurement on the box that will train:
    python scripts/profile_step.py task=sqoop experiment=sqoop/syncnet
Prints ms/step, examples/s and peak memory for: eager, compile (default), + channels_last,
max-autotune without cudagraphs, reduce-overhead (CUDA graphs), and max-autotune (both).
CUDA graphs need static shapes: the trainer drops the last partial training batch for that.
"""
from __future__ import annotations
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import torch
from hydra import compose, initialize_config_dir
from src.core.registry import build_loss_fn, build_model, register_configs
from src.utils import set_torch_config

TASK_SHAPES = {'sort_of_clevr': (75, lambda B: torch.rand(B, 18), 10), 'sqoop': (64, lambda B: torch.randint(0, 36, (B, 3)), 2)}


def step_time(model, loss_fn, batch, n=10):
    opt = torch.optim.AdamW(model.parameters(), lr=3e-4, fused=torch.cuda.is_available())
    def step():
        with torch.autocast('cuda', dtype=torch.bfloat16, enabled=torch.cuda.is_available()):
            loss, _ = loss_fn(model(batch), batch)
        loss.backward(); opt.step(); opt.zero_grad(set_to_none=True)
    for _ in range(3): step()
    if torch.cuda.is_available(): torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n): step()
    if torch.cuda.is_available(): torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n


def main() -> int:
    overrides = [a for a in sys.argv[1:] if '=' in a] + ['hydra.mode=RUN']
    register_configs()
    with initialize_config_dir(config_dir=os.path.abspath('conf'), version_base='1.3'):
        cfg = compose(config_name='config', overrides=overrides)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    set_torch_config(device)
    H, q, _ = TASK_SHAPES[cfg.dataset.name]; B = int(cfg.train.train_bs) if device == 'cuda' else 32
    batch = {'images': torch.rand(B, 3, H, H, device=device), 'questions': q(B).to(device), 'answers': torch.randint(0, 2, (B,), device=device)}
    loss_fn = build_loss_fn(cfg)
    print(f'{cfg.dataset.name} / {cfg.model.name} on {device}, batch {B}')
    variants = [('eager', {}, False), ('compile', {'mode': 'default'}, False), ('compile + channels_last', {'mode': 'default'}, True)]
    if device == 'cuda':
        variants += [('compile max-autotune-no-cudagraphs', {'mode': 'max-autotune-no-cudagraphs'}, False),
                     ('compile max-autotune-no-cudagraphs + channels_last', {'mode': 'max-autotune-no-cudagraphs'}, True),
                     ('compile reduce-overhead (cudagraphs)', {'mode': 'reduce-overhead'}, False),
                     ('compile reduce-overhead (cudagraphs) + channels_last', {'mode': 'reduce-overhead'}, True),
                     ('compile max-autotune (autotune + cudagraphs)', {'mode': 'max-autotune'}, True)]
    for label, ckw, cl in variants:
        model = build_model(cfg).to(device)
        if cl: model = model.to(memory_format=torch.channels_last); batch['images'] = batch['images'].contiguous(memory_format=torch.channels_last)
        else: batch['images'] = batch['images'].contiguous()
        if ckw:
            try: model = torch.compile(model, **ckw)
            except Exception as e: print(f'   {label:52s} compile unavailable: {type(e).__name__}'); continue
        try:
            if device == 'cuda': torch.cuda.reset_peak_memory_stats()
            dt = step_time(model, loss_fn, batch)
            mem = f'   peak {torch.cuda.max_memory_allocated() / 2**30:5.2f} GB' if device == 'cuda' else ''
            print(f'   {label:52s} {dt*1000:8.1f} ms/step   {B/dt:8.0f} ex/s{mem}')
        except Exception as e:
            print(f'   {label:52s} failed: {type(e).__name__}: {str(e)[:80]}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
