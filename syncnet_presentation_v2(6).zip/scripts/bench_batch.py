#!/usr/bin/env python3
"""Can this box take the effective batch as one real batch instead of accumulation?
For an experiment, time one OPTIMISER step (same examples per step, so the schedule and the
numbers are unchanged) under several (train_bs, grad_accum) splits of the effective batch,
with the real loaders and the experiment's compile settings, and report ms per optimiser
step, examples/s and peak memory -- or OOM. Fewer, larger micro-batches are faster per step
when they fit; the peak memory column says whether they leave room for a second run on the GPU.
    python scripts/bench_batch.py task=sqoop experiment=sqoop/baselines/relnet
    python scripts/bench_batch.py task=sqoop experiment=sqoop/baselines/conv --splits 256x8,512x4,1024x2,2048x1
Needs the experiment's default split on disk (prepare it first) and one GPU.
"""
from __future__ import annotations
import argparse, json, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

WORKER = r'''
import os, sys, time, json, torch
sys.path.insert(0, %(root)r)
from hydra import compose, initialize_config_dir
from src.core.registry import register_configs, build_model, build_loss_fn, build_dataloaders
from src.utils import set_torch_config
register_configs()
with initialize_config_dir(config_dir=os.path.join(%(root)r, 'conf'), version_base='1.3'):
    cfg = compose(config_name='config', overrides=%(overrides)r + ['hydra.mode=RUN'])
set_torch_config('cuda')
loaders = build_dataloaders(cfg, 'cuda')
model = build_model(cfg).cuda()
if cfg.train.channels_last: model = model.to(memory_format=torch.channels_last)
if cfg.train.compile_model: model = torch.compile(model, mode=cfg.train.compile_mode)
loss_fn = build_loss_fn(cfg); opt = torch.optim.AdamW(model.parameters(), lr=3e-4, fused=True)
accum = int(cfg.train.grad_accum); it = iter(loaders[0])
def opt_step():
    for _ in range(accum):
        batch = next(it)
        with torch.autocast('cuda', dtype=torch.bfloat16):
            loss, _ = loss_fn(model(batch), batch)
        (loss / accum).backward()
    opt.step(); opt.zero_grad(set_to_none=True)
for _ in range(3): opt_step()
torch.cuda.synchronize(); torch.cuda.reset_peak_memory_stats(); t0 = time.perf_counter()
for _ in range(%(steps)d): opt_step()
torch.cuda.synchronize(); dt = (time.perf_counter() - t0) / %(steps)d
print('RESULT ' + json.dumps({'ms': dt * 1000, 'ex_s': accum * int(cfg.train.train_bs) / dt, 'peak_gb': torch.cuda.max_memory_allocated() / 2**30}))
'''


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('overrides', nargs='+'); ap.add_argument('--splits', default='256x8,512x4,1024x2,2048x1'); ap.add_argument('--steps', type=int, default=10)
    args = ap.parse_args()
    import torch
    total_gb = torch.cuda.get_device_properties(0).total_memory / 2**30
    print(f'{torch.cuda.get_device_name(0)} ({total_gb:.0f} GB); {args.steps} timed optimiser steps each')
    for split in args.splits.split(','):
        bs, accum = (int(x) for x in split.lower().split('x'))
        ov = list(args.overrides) + [f'train.train_bs={bs}', f'train.grad_accum={accum}', 'train.loader_mode=dataloader', 'train.num_workers=3']
        p = subprocess.run([sys.executable, '-c', WORKER % {'root': ROOT, 'overrides': ov, 'steps': args.steps}], capture_output=True, text=True)
        line = [l for l in p.stdout.splitlines() if l.startswith('RESULT ')]
        if not line:
            err = (p.stderr.strip().splitlines() or ['?'])[-1]
            print(f'   {bs:5d} x {accum}  (eff. {bs*accum:5d})   {"OOM" if "out of memory" in p.stderr else "FAILED: " + err[:90]}')
            continue
        r = json.loads(line[0][7:])
        room = 'two runs fit' if 2 * r['peak_gb'] * 1.15 < total_gb else ('one run fits' if r['peak_gb'] * 1.15 < total_gb else 'tight')
        print(f'   {bs:5d} x {accum}  (eff. {bs*accum:5d})   {r["ms"]:8.0f} ms/opt-step   {r["ex_s"]:7.0f} ex/s   peak {r["peak_gb"]:5.1f} GB   {room}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
