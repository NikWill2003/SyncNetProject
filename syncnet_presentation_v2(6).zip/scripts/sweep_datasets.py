#!/usr/bin/env python3
"""Print the dataset overrides an experiment's sweep will need, one combination per line,
so every split can be generated before the GPU jobs start:
    python -m scripts.sweep_datasets sqoop sqoop/syncnet
    -> dataset.rhs_variety=1
       dataset.rhs_variety=2 ...
Prints nothing when the sweep does not touch dataset keys (the default split only)."""
from __future__ import annotations
import itertools, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from hydra import compose, initialize_config_dir
from omegaconf import OmegaConf
from src.core.registry import register_configs


def main() -> int:
    task, exp, *extra = sys.argv[1:]
    register_configs()
    with initialize_config_dir(config_dir=os.path.abspath('conf'), version_base='1.3'):
        cfg = compose(config_name='config', overrides=[f'task={task}', f'experiment={exp}', *extra], return_hydra_config=True)
    params = OmegaConf.to_container(cfg.hydra.sweeper.get('params', {}) or {})
    keys = {k: [v.strip() for v in str(vals).split(',')] for k, vals in params.items() if k.startswith('dataset.')}
    fixed = [o for o in extra if o.startswith('dataset.')]
    for combo in itertools.product(*keys.values()):
        print(' '.join([f'{k}={v}' for k, v in zip(keys, combo)] + fixed) if keys else ' '.join(fixed))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
