#!/usr/bin/env python3
"""Every experiment on both tasks, every SyncNet ablation, every override view: build,
forward on a real-shaped batch, backward. Then the two invariants that keep the
ablation and override suites honest:
  1. an override view adds no parameters to the canonical (as_ only ever drops parts);
  2. an ablation cell's resolved config differs from the canonical in model.ablation only.
    python scripts/check_wiring.py
"""
from __future__ import annotations
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import torch
from hydra import compose, initialize_config_dir
from omegaconf import OmegaConf
from src.core.registry import build_callbacks, build_model, register_configs
from src.models.syncnet import ABLATIONS, SIMPLIFICATIONS
from src.models.syncnet.overrides import OVERRIDES, as_

EXPERIMENTS = ['syncnet'] + [f'baselines/{m}' for m in ('question_only', 'conv', 'relnet', 'film', 'transformer', 'shared_workspace')]
SHAPES = {'sort_of_clevr': (75, lambda: torch.rand(2, 18), 10), 'sqoop': (64, lambda: torch.randint(0, 36, (2, 3)), 2)}


def flat(cfg):
    out = {}
    def walk(d, pre=''):
        for k, v in d.items():
            if isinstance(v, dict): walk(v, pre + k + '.')
            else: out[pre + k] = v
    walk(OmegaConf.to_container(cfg, resolve=True)); return out


def main() -> int:
    register_configs(); fails = 0
    with initialize_config_dir(config_dir=os.path.abspath('conf'), version_base='1.3'):
        for task, (H, q, _) in SHAPES.items():
            batch = {'images': torch.rand(2, 3, H, H), 'questions': q(), 'answers': torch.zeros(2, dtype=torch.long)}
            for exp in EXPERIMENTS:
                t0 = time.time()
                try:
                    cfg = compose(config_name='config', overrides=[f'task={task}', f'experiment={task}/{exp}', 'hydra.mode=RUN'])
                    model = build_model(cfg); build_callbacks(cfg, model)
                    model(batch)['logits'].sum().backward()
                    print(f'ok   {task}/{exp:27s} {sum(p.numel() for p in model.parameters()):>9,} params ({time.time()-t0:.0f}s)')
                except Exception as e:
                    fails += 1; print(f'FAIL {task}/{exp}: {type(e).__name__}: {str(e)[:100]}')
            canon_cfg = compose(config_name='config', overrides=[f'task={task}', f'experiment={task}/syncnet', 'hydra.mode=RUN'])
            canon = build_model(canon_cfg); keys = set(canon.state_dict()); c0 = flat(canon_cfg)
            for name in ABLATIONS:
                if name is None: continue
                cfg = compose(config_name='config', overrides=[f'task={task}', f'experiment={task}/syncnet', f'model.ablation={name}', 'hydra.mode=RUN'])
                try:
                    m = build_model(cfg); m(batch)['logits'].sum().backward()
                    diff = {k for k in set(flat(cfg)) | set(c0) if flat(cfg).get(k) != c0.get(k) and not k.startswith('hydra')}
                    assert diff == {'model.ablation'}, f'config differs in {sorted(diff)}'
                    print(f'ok   {task}/syncnet ablation={name}')
                except Exception as e:
                    fails += 1; print(f'FAIL {task}/syncnet ablation={name}: {type(e).__name__}: {str(e)[:100]}')
            for name in SIMPLIFICATIONS:
                cfg = compose(config_name='config', overrides=[f'task={task}', f'experiment={task}/syncnet', f'model.simplification={name}', 'hydra.mode=RUN'])
                try:
                    m = build_model(cfg); m(batch)['logits'].sum().backward()
                    diff = {k for k in set(flat(cfg)) | set(c0) if flat(cfg).get(k) != c0.get(k) and not k.startswith('hydra')}
                    assert diff == {'model.simplification'}, f'config differs in {sorted(diff)}'
                    print(f'ok   {task}/syncnet simplification={name}')
                except Exception as e:
                    fails += 1; print(f'FAIL {task}/syncnet simplification={name}: {type(e).__name__}: {str(e)[:100]}')
            for key, spec in OVERRIDES.items():
                if not hasattr(spec.callback_class, 'view'):
                    continue
                try:
                    v = as_(canon, spec.callback_class.view); v(batch)
                    assert not (set(v.state_dict()) - keys), 'override view adds parameters'
                    print(f'ok   {task}/syncnet override={key}')
                except Exception as e:
                    fails += 1; print(f'FAIL {task}/syncnet override={key}: {type(e).__name__}: {str(e)[:100]}')
    print(f'---- {fails} failures'); return 1 if fails else 0


if __name__ == '__main__':
    raise SystemExit(main())
