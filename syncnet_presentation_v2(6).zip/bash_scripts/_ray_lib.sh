# Shared runner for Vast boxes: one experiment = one Hydra multirun launched through Ray,
# every job reserving GPU_SHARE of a GPU (0.5 = two runs per GPU) and a matching share of
# the cores. A campaign script calls run_experiment once per experiment.
#
#   run_experiment task=<task> experiment=<task>/<name> [extra overrides...]
#
# Env: GPU_SHARE (default 0.5), NGPU (detected), SKIP_PREP=1, PREFLIGHT=0 (skip the smoke),
#      PREFLIGHT_ONLY=1 (smoke every experiment, run nothing), PREFLIGHT_STEPS (default 10), LOG.
# Contract kept for vast_worker: one "ok <job>" / "FAIL <job>" line per job, and
# "ok <experiment>" / "FAIL <experiment>" for the sweep.

_ray_up() {
    if ! ray status >/dev/null 2>&1; then
        echo "[ray] starting head with ${NGPU} GPU(s)"
        ray start --head --num-gpus "${NGPU}" --disable-usage-stats >/dev/null 2>&1 || { echo "FAIL ray_start"; return 1; }
        sleep 3
    fi
}

_prepare_for() {  # generate every split the sweep needs, concurrently, before any GPU job
    local task="$1"; shift
    local combos; combos="$(python -m scripts.sweep_datasets "$task" "$@")" || { echo "FAIL _prepare (sweep_datasets)"; return 1; }
    if [ -z "$(echo "$combos" | tr -d '[:space:]')" ]; then                 # the sweep uses the task's default split only
        echo "[prepare] $task: default split"
        python -m scripts.prepare_dataset "task=$task" > "$LOG/_prepare.log" 2>&1 && echo "ok   _prepare" || { echo "FAIL _prepare ($LOG/_prepare.log)"; return 1; }
        return 0
    fi
    echo "[prepare] $task: $(echo "$combos" | wc -l) split(s)"
    while IFS= read -r ov; do
        echo "  prepare $ov"
    done <<< "$combos"
    python -m scripts.prepare_dataset -cn prepare_parallel -m "task=$task" $(echo "$combos" | python -c "
import sys; rows=[l.split() for l in sys.stdin.read().splitlines() if l.strip()]
keys=sorted({k.split('=')[0] for r in rows for k in r})
print(' '.join(f\"{k}={','.join(sorted({dict(x.split('=') for x in r)[k] for r in rows if k in dict(x.split('=') for x in r)}))}\" for k in keys))") \
        > "$LOG/_prepare.log" 2>&1 && echo "ok   _prepare" || { echo "FAIL _prepare ($LOG/_prepare.log)"; return 1; }
}

# Preflight: every job of the sweep, exactly as configured (model, batch, accumulation,
# compile, loader workers, callbacks), for a handful of steps with the callbacks capped to
# one batch and no wandb. Overlapped through Ray like the real run. Any failure aborts.
_preflight() {  # <task> <exp> [overrides...]
    local task="$1" exp="$2"; shift 2
    local name; name="$(basename "$exp")"
    local results="$LOG/preflight.$name.log"; : > "$results"
    echo "[preflight] $exp: every job for ${PREFLIGHT_STEPS:-10} steps"
    python -u -m scripts.main_parallel "task=$task" "experiment=$exp" \
        "hydra.launcher.ray.remote.num_gpus=${GPU_SHARE:-0.5}" \
        "logging.results_log=$results" \
        "hydra.sweep.dir=$LOG/preflight/$name" \
        logging.preflight=true "train.n_steps=${PREFLIGHT_STEPS:-10}" logging.eval_log_interval=5 logging.train_log_interval=5 \
        train.early_stop_patience=null logging.save_best=false wandb.enabled=false "$@" > "$LOG/preflight.$name.driver.log" 2>&1
    local rc=$? failed ok
    failed=$(grep -c '^FAIL' "$results" 2>/dev/null); failed=${failed:-0}
    ok=$(grep -c '^ok' "$results" 2>/dev/null); ok=${ok:-0}
    if [ "$rc" -eq 0 ] && [ "$failed" -eq 0 ] && [ "$ok" -gt 0 ]; then
        echo "ok   preflight $exp ($ok jobs)"; return 0
    fi
    echo "FAIL preflight $exp exit=$rc failed_jobs=$failed ok_jobs=$ok ($LOG/preflight.$name.driver.log)"
    grep '^FAIL' "$results" | head -5 | sed 's/^/       /'
    return 1
}

run_experiment() {
    local task="${1#task=}"; local exp="${2#experiment=}"; shift 2
    local name; name="$(basename "$exp")"
    local results="$LOG/results.$name.log"; : > "$results"
    _ray_up || return 1
    if [ "${SKIP_PREP:-0}" != 1 ]; then _prepare_for "$task" "$exp" "$@" || return 1; fi
    if [ "${PREFLIGHT:-1}" != 0 ]; then _preflight "$task" "$exp" "$@" || return 2; fi
    [ "${PREFLIGHT_ONLY:-0}" = 1 ] && return 0
    echo "RUNNING $exp (gpu share ${GPU_SHARE:-0.5})"
    tail -n 0 -F "$results" 2>/dev/null &                      # per-job ok/FAIL lines as they land
    local bridge=$!
    python -u -m scripts.main_parallel "task=$task" "experiment=$exp" \
        "hydra.launcher.ray.remote.num_gpus=${GPU_SHARE:-0.5}" \
        "logging.results_log=$results" \
        "$@" > "$LOG/$name.log" 2>&1
    local rc=$?
    sleep 1; kill "$bridge" 2>/dev/null; wait "$bridge" 2>/dev/null
    local failed ok
    failed=$(grep -c '^FAIL' "$results" 2>/dev/null); failed=${failed:-0}
    ok=$(grep -c '^ok' "$results" 2>/dev/null); ok=${ok:-0}
    if [ "$rc" -eq 0 ] && [ "$failed" -eq 0 ]; then echo "ok   $exp ($ok jobs)"; return 0; fi
    echo "FAIL $exp exit=$rc failed_jobs=$failed ($LOG/$name.log)"; return 1
}

run_campaign() {  # EXPERIMENTS=( "task=... experiment=... [overrides]" ... )
    export NGPU="${NGPU:-$(nvidia-smi -L 2>/dev/null | wc -l)}"; [ "${NGPU:-0}" -ge 1 ] 2>/dev/null || NGPU=1
    mkdir -p "$LOG"
    echo "[campaign] $CAMPAIGN: ${#EXPERIMENTS[@]} experiment(s) on $NGPU GPU(s), share ${GPU_SHARE:-0.5}"
    # Every experiment is preflighted before it runs; a preflight failure (rc 2) aborts the
    # whole campaign, because a box that fails one configuration should not spend a day
    # on the others until someone has looked.
    local rc=0 spec
    for spec in "${EXPERIMENTS[@]}"; do
        read -r -a parts <<< "$spec"
        run_experiment "${parts[@]}"; local r=$?
        if [ "$r" -eq 2 ]; then echo "FAIL campaign aborted: preflight failed for ${parts[1]#experiment=}"; return 2; fi
        [ "$r" -ne 0 ] && rc=1
    done
    return $rc
}
